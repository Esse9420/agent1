"""
Orchestrator  --  the central coordination hub that boots all agents,
wires them together, and provides the system's external API.
"""

import asyncio
import signal
from typing import Optional

from core.message_bus import MessageBus
from core.task_manager import TaskManager, Task
from core.memory import SharedMemory
from core.tool_base import ToolRegistry
from core.workflow_engine import WorkflowEngine
from core.monitoring import Logger

from agents import (
    PlannerAgent, ExecutorAgent, MonitorAgent,
    AnalyzerAgent, CoordinatorAgent,
)
from tools.shell_tool import ShellTool
from tools.file_tool import FileTool
from tools.web_tool import WebTool


class AgentOrchestrator:
    """
    Top-level orchestrator. Boots all agents, connects components,
    and provides a unified API for the system.
    """

    def __init__(self, log_dir: Optional[str] = None):
        self.logger = Logger("Orchestrator", output_dir=log_dir)
        self.message_bus = MessageBus()
        self.task_manager = TaskManager()
        self.memory = SharedMemory()
        self.tool_registry = ToolRegistry()
        self.workflow_engine = WorkflowEngine(self.task_manager)

        self.agents: dict[str, object] = {}
        self._running = False
        self._register_default_tools()

    def _register_default_tools(self):
        """Register built-in tools that agents can use."""
        self.tool_registry.register_multiple(
            ShellTool(),
            FileTool(),
            WebTool(),
        )
        self.logger.info(f"Registered {len(self.tool_registry.all)} default tools")

    def _create_agents(self):
        """Instantiate all agent types with shared dependencies."""
        deps = {
            "message_bus": self.message_bus,
            "task_manager": self.task_manager,
            "memory": self.memory,
            "tool_registry": self.tool_registry,
        }

        self.agents = {
            "planner": PlannerAgent("planner-01", **deps),
            "executor": ExecutorAgent("executor-01", **deps),
            "monitor": MonitorAgent("monitor-01", **deps),
            "analyzer": AnalyzerAgent("analyzer-01", **deps),
            "coordinator": CoordinatorAgent("coordinator-01", **deps),
        }

        # Register task handlers for each agent
        for agent_id, agent in self.agents.items():
            self.task_manager.register_handler(agent_id, agent.handle_task)

        # Register agent mailboxes on the message bus
        for agent_id in self.agents:
            self.message_bus.register_agent(agent_id)

        self.logger.info(f"Created {len(self.agents)} agents: {list(self.agents.keys())}")

    def _setup_subscriptions(self):
        """Wire up inter-agent message subscriptions."""
        agents = self.agents

        # Coordinator listens for task completions
        async def on_task_complete(task: Task):
            msg = f"[{task.status.value}] {task.name} ({task.agent_type})"
            if task.error:
                msg += f"  --  ERROR: {task.error}"
            await agents["coordinator"].send_message("task.completed", {
                "task_id": task.id,
                "status": task.status.value,
                "agent_type": task.agent_type,
                "name": task.name,
                "has_error": task.error is not None,
                "duration_ms": task.duration_ms,
            })

            # Auto-alert on failure
            if task.status.value == "failed":
                await agents["monitor"].handle_task(Task.create(
                    name="auto_alert",
                    agent_type="monitor",
                    action="alert_if_needed",
                    params={"task_id": task.id, "error": task.error},
                ))

        self.task_manager.on_complete(on_task_complete)

        # Planner subscribe to replan requests
        agents["planner"].subscribe("plan.replan_request")

        # Monitor subscribe to heartbeats
        agents["monitor"].subscribe("agent.heartbeat")

        self.logger.info("Agent subscriptions configured")

    async def start(self):
        """Start all agents and background workers."""
        self._running = True
        self._create_agents()
        self._setup_subscriptions()

        for name, agent in self.agents.items():
            await agent.start()
            self.logger.info(f"Started agent: {name}")

        await self.task_manager.start_worker()
        self.logger.info("Task manager worker started")
        self.logger.info(f"Orchestrator ready - {len(self.agents)} agents online")

    async def stop(self):
        """Gracefully shut down all agents."""
        self._running = False
        await self.task_manager.stop_worker()
        for name, agent in self.agents.items():
            await agent.stop()
        self.logger.info("Orchestrator stopped")

    # ─── Public API ─────────────────────────────────────────────

    async def submit_task(self, name: str, agent_type: str, action: str,
                          params: Optional[dict] = None,
                          depends_on: Optional[list[str]] = None) -> str:
        """Submit a single task to the system."""
        task = Task.create(
            name=name,
            agent_type=agent_type,
            action=action,
            params=params or {},
            depends_on=depends_on or [],
        )
        self.task_manager.add_task(task)
        self.logger.info(f"Task submitted: {name}  ->  {agent_type}", task_id=task.id)
        return task.id

    async def run_workflow(self, workflow, return_workflow: bool = False):
        """Execute a complete workflow."""
        self.workflow_engine.add_workflow(workflow)
        self.logger.info(f"Workflow started: {workflow.name} ({len(workflow.steps)} steps)")
        result = await self.workflow_engine.execute(workflow)
        self.logger.info(f"Workflow completed: {workflow.name}  --  {result.status.value}")
        return result if return_workflow else result.status.value

    async def plan_and_execute(self, goal: str, context: Optional[dict] = None) -> dict:
        """High-level: describe a goal, get a plan, execute it. One-shot orchestration."""
        # Step 1: Plan
        plan_task_id = await self.submit_task(
            name=f"plan:{goal[:50]}",
            agent_type="planner",
            action="generate_plan",
            params={"goal": goal, "context": context or {}},
        )

        # Wait for the plan
        for _ in range(100):
            plan_task = self.task_manager.get_task(plan_task_id)
            if plan_task and plan_task.status.value in ("completed", "failed"):
                break
            await asyncio.sleep(0.1)

        if not plan_task or plan_task.status.value != "completed":
            return {"success": False, "error": "Planning failed", "task": plan_task_id}

        plan = plan_task.result.get("plan", [])

        # Step 2: Distribute via coordinator
        dist_task_id = await self.submit_task(
            name="distribute_plan",
            agent_type="coordinator",
            action="distribute_tasks",
            params={"tasks": [
                {
                    "name": step["step"],
                    "agent_type": step.get("agent", "executor"),
                    "action": step["step"],
                    "params": {"description": step.get("description", "")},
                }
                for step in plan
            ]},
        )

        return {
            "success": True,
            "plan": plan,
            "plan_task_id": plan_task_id,
            "distribution_task_id": dist_task_id,
        }

    def get_agent(self, name: str):
        """Get an agent instance by name."""
        return self.agents.get(name)

    def status(self) -> dict:
        """Full system status report."""
        return {
            "running": self._running,
            "agents": {name: agent.status_report() for name, agent in self.agents.items()},
            "tasks": self.task_manager.summary(),
            "tools": self.tool_registry.list_tools(),
        }
