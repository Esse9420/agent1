import asyncio
from core.tool_base import BaseTool, ToolResult


class ShellTool(BaseTool):
    """Execute shell commands."""

    def __init__(self):
        super().__init__()
        self.description = "Execute shell commands and return output"

    def validate_params(self, **kwargs) -> str | None:
        if not kwargs.get("command"):
            return "command is required"
        return None

    async def execute(self, **kwargs) -> ToolResult:
        command = kwargs["command"]
        timeout = kwargs.get("timeout", 30)

        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return ToolResult(
                success=proc.returncode == 0,
                data={
                    "stdout": stdout.decode(errors="replace")[:5000],
                    "stderr": stderr.decode(errors="replace")[:2000],
                    "returncode": proc.returncode,
                },
            )
        except asyncio.TimeoutError:
            proc.kill()
            return ToolResult(success=False, error=f"Timeout ({timeout}s)")
