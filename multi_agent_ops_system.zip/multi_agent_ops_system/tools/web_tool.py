from core.tool_base import BaseTool, ToolResult


class WebTool(BaseTool):
    """Make HTTP requests to web services."""

    def __init__(self):
        super().__init__()
        self.description = "Make HTTP requests to interact with web services and APIs"

    def validate_params(self, **kwargs) -> str | None:
        if not kwargs.get("url"):
            return "url is required"
        return None

    async def execute(self, **kwargs) -> ToolResult:
        url = kwargs["url"]
        method = kwargs.get("method", "GET").upper()
        headers = kwargs.get("headers", {})
        body = kwargs.get("body")
        timeout = kwargs.get("timeout", 15)

        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method, url, headers=headers, json=body,
                    timeout=aiohttp.ClientTimeout(total=timeout),
                ) as resp:
                    text = await resp.text()
                    return ToolResult(
                        success=resp.ok,
                        data={
                            "status": resp.status,
                            "body": text[:5000],
                            "headers": dict(resp.headers),
                        },
                    )
        except ImportError:
            return ToolResult(success=False, error="aiohttp not installed")
        except Exception as e:
            return ToolResult(success=False, error=str(e))
