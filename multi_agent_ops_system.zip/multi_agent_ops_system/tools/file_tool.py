import os
from core.tool_base import BaseTool, ToolResult


class FileTool(BaseTool):
    """Read, write, and manage files."""

    def __init__(self):
        super().__init__()
        self.description = "Read, write, and manage files on the filesystem"

    def validate_params(self, **kwargs) -> str | None:
        if not kwargs.get("operation"):
            return "operation is required (read/write/delete/list)"
        if kwargs.get("operation") in ("read", "write", "delete") and not kwargs.get("path"):
            return "path is required for this operation"
        return None

    async def execute(self, **kwargs) -> ToolResult:
        op = kwargs["operation"]
        path = kwargs.get("path", "")
        content = kwargs.get("content")

        try:
            if op == "read":
                if not os.path.exists(path):
                    return ToolResult(success=False, error=f"File not found: {path}")
                with open(path, "r", encoding="utf-8") as f:
                    return ToolResult(success=True, data={"content": f.read()})

            elif op == "write":
                os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content or "")
                return ToolResult(success=True, data={"path": path, "size": len(content or "")})

            elif op == "delete":
                if os.path.exists(path):
                    os.remove(path)
                    return ToolResult(success=True, data={"path": path, "deleted": True})
                return ToolResult(success=False, error="File not found")

            elif op == "list":
                if not os.path.isdir(path):
                    return ToolResult(success=False, error=f"Not a directory: {path}")
                entries = os.listdir(path)
                return ToolResult(success=True, data={"files": entries, "count": len(entries)})

            else:
                return ToolResult(success=False, error=f"Unknown operation: {op}")
        except Exception as e:
            return ToolResult(success=False, error=str(e))
