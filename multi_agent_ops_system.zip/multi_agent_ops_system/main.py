#!/usr/bin/env python3
"""
Multi-Agent Collaborative Operations Automation System
======================================================
Entry point. Boots the orchestrator and provides CLI or interactive modes.
"""

import asyncio
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from orchestrator import AgentOrchestrator
from workflows.deployment_workflow import create_deployment_workflow
from workflows.incident_response_workflow import create_incident_response_workflow
from config import SystemConfig


async def demo_deployment(orchestrator: AgentOrchestrator):
    """Demo: deploy a service with multi-agent orchestration."""
    print("\n" + "=" * 60)
    print("Demo: Service Deployment")
    print("=" * 60)

    workflow = create_deployment_workflow(
        service_name="api-gateway",
        version="v2.1.0",
        target="staging",
    )
    result = await orchestrator.run_workflow(workflow)
    print(f"Deployment result: {result}")
    return result


async def demo_incident(orchestrator: AgentOrchestrator):
    """Demo: automated incident response."""
    print("\n" + "=" * 60)
    print("Demo: Incident Response")
    print("=" * 60)

    workflow = create_incident_response_workflow(
        incident_id="INC-2024-0421",
        severity="high",
        description="API gateway timeout errors above 5% threshold",
        affected_service="api-gateway",
    )
    result = await orchestrator.run_workflow(workflow)
    print(f"Incident response result: {result}")
    return result


async def demo_plan_and_execute(orchestrator: AgentOrchestrator):
    """Demo: natural-language goal  ->  automated execution."""
    print("\n" + "=" * 60)
    print("Demo: Plan & Execute")
    print("=" * 60)

    result = await orchestrator.plan_and_execute(
        goal="Deploy monitoring stack to production",
        context={"environment": "production", "team": "platform"},
    )
    print(f"Plan & execute result: {result}")
    return result


async def main():
    config = SystemConfig()
    orchestrator = AgentOrchestrator(log_dir=config.log_dir)

    try:
        await orchestrator.start()
        print(f"\n{'=' * 60}")
        print(f"Multi-Agent Ops System - {len(orchestrator.agents)} agents ready")
        print(f"   Agents: {', '.join(orchestrator.agents.keys())}")
        print(f"   Tools:  {len(orchestrator.tool_registry.all)} registered")
        print(f"{'=' * 60}\n")

        # Run demos
        await demo_deployment(orchestrator)
        await demo_incident(orchestrator)
        await demo_plan_and_execute(orchestrator)

        # Print final status
        import json
        print("\n" + "=" * 60)
        print("Final System Status")
        print("=" * 60)
        status = orchestrator.status()
        print(json.dumps(status, indent=2, default=str))

    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await orchestrator.stop()
        print("System stopped.")


if __name__ == "__main__":
    asyncio.run(main())
