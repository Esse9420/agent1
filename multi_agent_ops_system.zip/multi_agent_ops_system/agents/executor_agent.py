"""Specialized Agent: Executor  --  carries out operational tasks."""
import asyncio
from core.agent_base import BaseAgent
from core.task_manager import Task, TaskStatus


class ExecutorAgent(BaseAgent):
    """Executes operational tasks using available tools."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Executes operational tasks and commands"
        self._execution_history: list[dict] = []

    async def handle_task(self, task: Task) -> dict:
        self.status = self.status.BUSY
        self.log("info", f"Executing: {task.name}", action=task.action)

        action = task.action
        params = task.params

        try:
            if action == "shell":
                result = await self._exec_shell(params)
            elif action == "file_operation":
                result = await self._exec_file_ops(params)
            elif action == "api_call":
                result = await self._exec_api_call(params)
            elif action == "run_script":
                result = await self._exec_script(params)
            elif action == "deploy":
                result = await self._exec_deploy(params)
            else:
                result = await self._exec_generic(action, params)

            self._execution_history.append({
                "task_id": task.id,
                "action": action,
                "success": result.get("success", False),
            })
            self.metrics.counter(f"executions:{action}")

            self.status = self.status.IDLE
            return result
        except Exception as e:
            self.status = self.status.ERROR
            self.log("error", f"Execution failed: {e}")
            return {"success": False, "error": str(e)}

    async def _exec_shell(self, params: dict) -> dict:
        cmd = params.get("command", "")
        timeout = params.get("timeout", 30)
        self.log("info", f"Shell: {cmd[:200]}")
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
            return {
                "success": proc.returncode == 0,
                "stdout": stdout.decode(errors="replace")[:5000],
                "stderr": stderr.decode(errors="replace")[:2000],
                "returncode": proc.returncode,
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"success": False, "error": f"Command timed out ({timeout}s)"}

    async def _exec_file_ops(self, params: dict) -> dict:
        operation = params.get("operation", "read")
        path = params.get("path", "")
        content = params.get("content")

        import os
        try:
            if operation == "read":
                with open(path, "r", encoding="utf-8") as f:
                    return {"success": True, "content": f.read()}
            elif operation == "write":
                os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content or "")
                return {"success": True, "path": path}
            elif operation == "delete":
                if os.path.exists(path):
                    os.remove(path)
                    return {"success": True}
                return {"success": False, "error": "File not found"}
            elif operation == "list":
                if os.path.isdir(path):
                    return {"success": True, "files": os.listdir(path)}
                return {"success": False, "error": "Not a directory"}
            else:
                return {"success": False, "error": f"Unknown operation: {operation}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def _exec_api_call(self, params: dict) -> dict:
        import json
        try:
            import aiohttp
            method = params.get("method", "GET").upper()
            url = params.get("url", "")
            headers = params.get("headers", {})
            body = params.get("body")

            async with aiohttp.ClientSession() as session:
                async with session.request(method, url, headers=headers, json=body) as resp:
                    response_body = await resp.text()
                    return {
                        "success": resp.ok,
                        "status": resp.status,
                        "body": response_body[:5000],
                    }
        except ImportError:
            return {"success": False, "error": "aiohttp not installed"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def _exec_script(self, params: dict) -> dict:
        return await self._exec_shell({
            "command": params.get("script", ""),
            "timeout": params.get("timeout", 60),
        })

    async def _exec_deploy(self, params: dict) -> dict:
        self.log("info", f"Deploy: {params.get('target', 'unknown')}")
        steps = params.get("steps", [])
        results = []
        for step in steps:
            r = await self._exec_shell({"command": step, "timeout": params.get("timeout", 120)})
            results.append(r)
            if not r["success"]:
                return {"success": False, "results": results, "failed_step": step}
        return {"success": True, "results": results}

    async def _exec_generic(self, action: str, params: dict) -> dict:
        return {"success": True, "action": action, "params": params, "message": f"Executed {action}"}
