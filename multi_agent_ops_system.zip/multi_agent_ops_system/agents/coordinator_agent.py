"""Specialized Agent: Coordinator  --  orchestrates multi-agent workflows."""
from core.agent_base import BaseAgent
from core.task_manager import Task, TaskStatus


class CoordinatorAgent(BaseAgent):
    """Orchestrates multi-agent collaboration and conflict resolution."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Coordinates multi-agent collaboration and resolves conflicts"
        self._active_sessions: dict[str, dict] = {}

    async def handle_task(self, task: Task) -> dict:
        self.status = self.status.BUSY
        self.log("info", f"Coordinating: {task.name}")

        action = task.action
        params = task.params

        if action == "distribute_tasks":
            result = await self._distribute_tasks(params)
        elif action == "resolve_conflict":
            result = await self._resolve_conflict(params)
        elif action == "create_session":
            result = self._create_session(params)
        elif action == "aggregate_results":
            result = await self._aggregate_results(params)
        elif action == "broadcast":
            result = await self._broadcast(params)
        else:
            result = {"success": False, "error": f"Unknown action: {action}"}

        self.status = self.status.IDLE
        return result

    async def _distribute_tasks(self, params: dict) -> dict:
        tasks = params.get("tasks", [])
        assignments = []

        for t_def in tasks:
            task = Task.create(
                name=t_def.get("name", "unnamed"),
                agent_type=t_def.get("agent_type", "executor"),
                action=t_def.get("action", "shell"),
                params=t_def.get("params", {}),
                priority=t_def.get("priority", "NORMAL"),
                depends_on=t_def.get("depends_on", []),
            )
            self.task_manager.add_task(task)
            assignments.append({
                "task_id": task.id,
                "name": task.name,
                "agent_type": task.agent_type,
                "action": task.action,
            })
            self.log("info", f"Dispatched task {task.name} to {task.agent_type}",
                     task_id=task.id)

        return {"success": True, "assigned": len(assignments), "tasks": assignments}

    async def _resolve_conflict(self, params: dict) -> dict:
        conflicting_tasks = params.get("tasks", [])
        resolution_strategy = params.get("strategy", "priority")

        resolutions = []
        if resolution_strategy == "priority":
            sorted_tasks = sorted(conflicting_tasks, key=lambda t: t.get("priority", 0), reverse=True)
            for i, t in enumerate(sorted_tasks):
                resolutions.append({
                    "task_id": t.get("id"),
                    "order": i + 1,
                    "action": "execute" if i == 0 else "defer",
                })
        elif resolution_strategy == "dependency":
            for t in conflicting_tasks:
                deps = t.get("depends_on", [])
                resolutions.append({
                    "task_id": t.get("id"),
                    "blocked_by": deps,
                })

        return {"success": True, "strategy": resolution_strategy, "resolutions": resolutions}

    def _create_session(self, params: dict) -> dict:
        session_id = params.get("session_id", f"session_{len(self._active_sessions)}")
        agents = params.get("agents", [])
        objectives = params.get("objectives", [])

        self._active_sessions[session_id] = {
            "agents": agents,
            "objectives": objectives,
            "status": "active",
            "tasks": [],
        }
        self.remember(f"session:{session_id}", self._active_sessions[session_id], tags=["session"])

        return {"success": True, "session_id": session_id, "agent_count": len(agents)}

    async def _aggregate_results(self, params: dict) -> dict:
        task_ids = params.get("task_ids", [])
        results = []

        for tid in task_ids:
            task = self.task_manager.get_task(tid)
            if task:
                results.append({
                    "task_id": tid,
                    "name": task.name,
                    "status": task.status.value,
                    "result": task.result,
                    "error": task.error,
                })

        return {
            "success": True,
            "aggregated": len(results),
            "results": results,
        }

    async def _broadcast(self, params: dict) -> dict:
        topic = params.get("topic", "broadcast")
        content = params.get("content", {})
        await self.send_message(topic, content)
        return {"success": True, "topic": topic, "message": "Broadcast sent"}
