"""Specialized Agent: Analyzer  --  processes data and generates insights."""
from core.agent_base import BaseAgent
from core.task_manager import Task


class AnalyzerAgent(BaseAgent):
    """Analyzes operational data, logs, and generates reports."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Analyzes data, identifies patterns, and generates reports"

    async def handle_task(self, task: Task) -> dict:
        self.status = self.status.BUSY
        self.log("info", f"Analyzing: {task.name}", action=task.action)

        action = task.action
        params = task.params

        if action == "analyze_logs":
            result = await self._analyze_logs(params)
        elif action == "generate_report":
            result = self._generate_report(params)
        elif action == "root_cause":
            result = await self._root_cause_analysis(params)
        elif action == "summarize":
            result = self._summarize(params)
        elif action == "analyze_trend":
            result = self._analyze_trend(params)
        else:
            result = {"success": False, "error": f"Unknown action: {action}"}

        self.status = self.status.IDLE
        return result

    async def _analyze_logs(self, params: dict) -> dict:
        log_source = params.get("source", "")
        filter_pattern = params.get("filter", "")
        time_range = params.get("time_range", 3600)

        recent_history = self.bus.get_history(limit=200)
        relevant_msgs = [
            {
                "topic": m.topic,
                "sender": m.sender,
                "content": str(m.content)[:200],
                "time": m.timestamp,
            }
            for m in recent_history
            if not filter_pattern or filter_pattern in str(m.content)
        ]

        return {
            "success": True,
            "message_count": len(relevant_msgs),
            "samples": relevant_msgs[:20],
            "source": log_source,
        }

    def _generate_report(self, params: dict) -> dict:
        report_type = params.get("type", "summary")
        data = params.get("data", {})

        task_summary = self.task_manager.summary()
        report = {
            "type": report_type,
            "generated_at": __import__("time").time(),
            "task_summary": task_summary,
            "insights": [],
        }

        total = task_summary.get("total", 0)
        if total > 0:
            completion_rate = task_summary.get("completed", 0) / total * 100
            report["insights"].append(f"Task completion rate: {completion_rate:.1f}%")
            if task_summary.get("failed", 0) > 0:
                report["insights"].append(f"Failed tasks: {task_summary.get('failed', 0)}")

        return {"success": True, "report": report}

    async def _root_cause_analysis(self, params: dict) -> dict:
        error_message = params.get("error", "")
        context = params.get("context", {})

        causes = []

        logs = self.bus.get_history(limit=100)
        error_logs = [m for m in logs if "error" in str(m.content).lower()]

        if error_logs:
            causes.append({
                "type": "related_errors",
                "count": len(error_logs),
                "samples": [str(m.content)[:150] for m in error_logs[:5]],
            })

        if "timeout" in error_message.lower():
            causes.append({"type": "timeout", "likelihood": "high"})
        if "permission" in error_message.lower():
            causes.append({"type": "permission_denied", "likelihood": "high"})
        if "not found" in error_message.lower():
            causes.append({"type": "missing_resource", "likelihood": "high"})

        return {
            "success": True,
            "error": error_message,
            "possible_causes": causes,
            "recommendation": "Check related error logs and verify resource availability",
        }

    def _summarize(self, params: dict) -> dict:
        data = params.get("data", [])
        max_points = params.get("max_points", 5)

        if isinstance(data, list):
            summary = {
                "count": len(data),
                "sample": data[:max_points],
            }
        elif isinstance(data, dict):
            summary = {
                "keys": list(data.keys()),
                "key_count": len(data),
            }
        else:
            summary = {"value": str(data)[:500]}

        return {"success": True, "summary": summary}

    def _analyze_trend(self, params: dict) -> dict:
        metric_name = params.get("metric", "")
        data_points = params.get("data_points", [])

        if len(data_points) < 2:
            return {"success": True, "trend": "insufficient_data", "direction": "unknown"}

        values = [p.get("value", 0) for p in data_points]
        first_half = sum(values[:len(values)//2]) / max(len(values)//2, 1)
        second_half = sum(values[len(values)//2:]) / max(len(values) - len(values)//2, 1)

        if second_half > first_half * 1.1:
            direction = "increasing"
        elif second_half < first_half * 0.9:
            direction = "decreasing"
        else:
            direction = "stable"

        return {
            "success": True,
            "metric": metric_name,
            "direction": direction,
            "avg_before": first_half,
            "avg_after": second_half,
            "change_pct": ((second_half - first_half) / max(first_half, 0.001)) * 100,
        }
