"""Specialized Agent: Monitor  --  watches system state and task progress."""
import time
from core.agent_base import BaseAgent
from core.task_manager import Task


class MonitorAgent(BaseAgent):
    """Monitors system health, task progress, and operational metrics."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Monitors operations, health checks, and metrics"
        self._watchlist: dict[str, dict] = {}
        self._alert_thresholds: dict[str, float] = {
            "error_rate": 0.1,
            "latency_ms": 5000,
        }

    async def handle_task(self, task: Task) -> dict:
        self.status = self.status.BUSY

        action = task.action
        params = task.params

        if action == "health_check":
            result = self._check_health(params)
        elif action == "watch_task":
            result = await self._watch_task_progress(params)
        elif action == "collect_metrics":
            result = self._collect_metrics(params)
        elif action == "verify_result":
            result = self._verify_result(params)
        elif action == "alert_if_needed":
            result = await self._check_alerts(params)
        else:
            result = {"success": False, "error": f"Unknown action: {action}"}

        self.status = self.status.IDLE
        return result

    def _check_health(self, params: dict) -> dict:
        checks = params.get("checks", ["agent_status", "memory", "tools"])
        results = {}
        all_ok = True

        for check in checks:
            if check == "agent_status":
                results[check] = {"ok": self.status.value == "idle", "status": self.status.value}
            elif check == "memory":
                results[check] = {"ok": True, "entries": len(self.memory._store)}
            elif check == "tools":
                tools = self.tools.list_tools()
                results[check] = {"ok": len(tools) > 0, "count": len(tools)}
            else:
                results[check] = {"ok": False, "error": "Unknown check"}

            if not results[check]["ok"]:
                all_ok = False

        return {"success": True, "healthy": all_ok, "checks": results}

    async def _watch_task_progress(self, params: dict) -> dict:
        task_id = params.get("task_id", "")
        timeout = params.get("timeout", 60)
        poll_interval = params.get("poll_interval", 1.0)

        import asyncio
        start = time.time()
        while time.time() - start < timeout:
            task = self.task_manager.get_task(task_id)
            if not task:
                return {"success": False, "error": f"Task {task_id} not found"}
            if task.status.value in ("completed", "failed", "cancelled"):
                return {
                    "success": task.status.value == "completed",
                    "task_id": task_id,
                    "status": task.status.value,
                    "result": task.result,
                    "error": task.error,
                    "duration_ms": task.duration_ms,
                }
            await asyncio.sleep(poll_interval)

        return {"success": False, "error": f"Watch timeout ({timeout}s)", "task_id": task_id}

    def _collect_metrics(self, params: dict) -> dict:
        metric_snapshot = self.metrics.snapshot()
        task_summary = self.task_manager.summary()
        return {
            "success": True,
            "metrics": [{"name": m.name, "value": m.value} for m in metric_snapshot[-20:]],
            "task_summary": task_summary,
        }

    def _verify_result(self, params: dict) -> dict:
        expected = params.get("expected", {})
        actual = params.get("actual", {})
        checks = []

        for key, expected_val in expected.items():
            actual_val = actual.get(key)
            match = str(actual_val) == str(expected_val)
            checks.append({"key": key, "expected": expected_val, "actual": actual_val, "match": match})

        all_pass = all(c["match"] for c in checks)
        return {"success": True, "verified": all_pass, "checks": checks}

    async def _check_alerts(self, params: dict) -> dict:
        alerts = []
        task_summary = self.task_manager.summary()
        total = task_summary.get("total", 0)
        failed = task_summary.get("failed", 0)

        if total > 0 and failed / total > self._alert_thresholds["error_rate"]:
            alerts.append({
                "level": "warning",
                "message": f"High error rate: {failed}/{total} tasks failed",
            })

        return {"success": True, "alerts": alerts, "alert_count": len(alerts)}
