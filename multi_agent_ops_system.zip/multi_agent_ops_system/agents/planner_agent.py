"""Specialized Agent: Planner  --  decomposes goals into tasks."""
from core.agent_base import BaseAgent
from core.task_manager import Task, TaskPriority


class PlannerAgent(BaseAgent):
    """Analyzes objectives and produces structured task plans."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Decomposes high-level goals into executable task plans"

    async def handle_task(self, task: Task) -> dict:
        self.status = self.status.BUSY
        self.log("info", f"Planning: {task.name}", action=task.action)

        goal = task.params.get("goal", "")
        constraints = task.params.get("constraints", [])
        context = task.params.get("context", {})

        plan = await self._generate_plan(goal, constraints, context)
        self.remember(f"plan:{task.id}", plan, tags=["plan"])

        self.status = self.status.IDLE
        return {"plan": plan, "task_count": len(plan)}

    async def _generate_plan(self, goal: str, constraints: list, context: dict) -> list[dict]:
        """Generate a structured plan from a goal."""
        plan = [
            {
                "step": "analyze_requirements",
                "agent": "analyzer",
                "description": f"Analyze requirements for: {goal}",
            },
            {
                "step": "prepare_environment",
                "agent": "executor",
                "description": "Prepare execution environment and resources",
            },
            {
                "step": "execute_primary",
                "agent": "executor",
                "description": f"Execute primary operation: {goal}",
            },
            {
                "step": "verify_result",
                "agent": "monitor",
                "description": "Verify execution results",
            },
            {
                "step": "generate_report",
                "agent": "analyzer",
                "description": "Generate completion report",
            },
        ]
        return plan

    async def handle_message(self, message):
        if message.content.get("type") == "replan_request":
            original_plan = self.recall(f"plan:{message.content['plan_id']}")
            if original_plan:
                self.log("info", f"Replanning based on feedback: {message.content.get('reason', '')}")
                new_plan = await self._generate_plan(
                    message.content.get("goal", ""),
                    message.content.get("constraints", []),
                    {},
                )
                await self.send_message("plan.updated", {
                    "plan_id": message.content["plan_id"],
                    "plan": new_plan,
                })
