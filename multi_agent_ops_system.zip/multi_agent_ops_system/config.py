"""System configuration."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SystemConfig:
    log_dir: Optional[str] = "logs"
    task_worker_poll_interval: float = 0.2
    default_task_timeout: float = 300.0
    metrics_enabled: bool = True

    agent_configs: dict = field(default_factory=lambda: {
        "planner": {"agent_id": "planner-01"},
        "executor": {"agent_id": "executor-01"},
        "monitor": {"agent_id": "monitor-01"},
        "analyzer": {"agent_id": "analyzer-01"},
        "coordinator": {"agent_id": "coordinator-01"},
    })
