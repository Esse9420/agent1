"""
Example: Creating a custom tool.
"""
from core.tool_base import BaseTool, ToolResult


class DatabaseQueryTool(BaseTool):
    """Custom tool: query a database."""

    def __init__(self):
        super().__init__()
        self.description = "Execute SQL queries against configured databases"

    def validate_params(self, **kwargs) -> str | None:
        if not kwargs.get("query"):
            return "query is required"
        if not kwargs.get("connection_string"):
            return "connection_string is required"
        return None

    async def execute(self, **kwargs) -> ToolResult:
        query = kwargs["query"]
        conn_str = kwargs["connection_string"]
        timeout = kwargs.get("timeout", 10)

        # In production, use an actual DB driver like asyncpg, aiosqlite, etc.
        # This is a simulation:
        return ToolResult(
            success=True,
            data={
                "query": query[:100],
                "rows_affected": 0,
                "columns": ["id", "name", "status"],
                "rows": [
                    {"id": 1, "name": "service-a", "status": "healthy"},
                    {"id": 2, "name": "service-b", "status": "degraded"},
                ],
                "execution_ms": 12.5,
            },
        )


class SlackNotifierTool(BaseTool):
    """Custom tool: send notifications to Slack."""

    def __init__(self):
        super().__init__()
        self.description = "Send alert messages to Slack channels"

    def validate_params(self, **kwargs) -> str | None:
        if not kwargs.get("message"):
            return "message is required"
        return None

    async def execute(self, **kwargs) -> ToolResult:
        message = kwargs["message"]
        channel = kwargs.get("channel", "#ops-alerts")
        severity = kwargs.get("severity", "info")

        print(f"[SlackNotifier]  ->  #{channel} [{severity}] {message[:200]}")
        return ToolResult(
            success=True,
            data={
                "channel": channel,
                "message_preview": message[:100],
                "severity": severity,
                "delivered": True,
            },
        )


# Example: Register and use custom tools
async def example():
    from orchestrator import AgentOrchestrator

    orch = AgentOrchestrator()
    orch.tool_registry.register_multiple(
        DatabaseQueryTool(),
        SlackNotifierTool(),
    )

    await orch.start()

    # Coordinator agent uses the Slack notifier
    coordinator = orch.get_agent("coordinator")
    result = await coordinator.use_tool("SlackNotifierTool",
        message="Deployment completed successfully",
        channel="#deployments",
        severity="info",
    )
    print(f"Notifier result: success={result.success}, data={result.data}")

    await orch.stop()
