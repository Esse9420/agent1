"""
Example: Creating a custom specialized agent.
"""
from core.agent_base import BaseAgent
from core.task_manager import Task


class SecurityScannerAgent(BaseAgent):
    """Custom agent: scans for security vulnerabilities."""

    def __init__(self, agent_id: str, **kwargs):
        super().__init__(agent_id, **kwargs)
        self.description = "Security vulnerability scanner and auditor"

    async def handle_task(self, task: Task) -> dict:
        self.log("info", f"Security scan: {task.name}")

        action = task.action
        params = task.params

        if action == "scan_dependencies":
            return await self._scan_dependencies(params)
        elif action == "audit_config":
            return await self._audit_config(params)
        elif action == "check_compliance":
            return self._check_compliance(params)
        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    async def _scan_dependencies(self, params: dict) -> dict:
        packages = params.get("packages", [])
        findings = []
        for pkg in packages:
            findings.append({
                "package": pkg,
                "status": "clean",
                "cve_count": 0,
            })
        return {"success": True, "scanned": len(packages), "findings": findings}

    async def _audit_config(self, params: dict) -> dict:
        config_path = params.get("config_path", "")
        return {
            "success": True,
            "path": config_path,
            "issues": [],
            "score": 95,
        }

    def _check_compliance(self, params: dict) -> dict:
        standard = params.get("standard", "SOC2")
        controls = params.get("controls", [])
        return {
            "success": True,
            "standard": standard,
            "compliant": True,
            "controls_passed": len(controls),
            "controls_total": len(controls),
        }


# Example: Register and use the custom agent
async def example():
    from orchestrator import AgentOrchestrator

    orch = AgentOrchestrator()
    await orch.start()

    # Register custom agent
    security_agent = SecurityScannerAgent("security-01",
        message_bus=orch.message_bus,
        task_manager=orch.task_manager,
        memory=orch.memory,
        tool_registry=orch.tool_registry,
    )
    orch.agents["security"] = security_agent
    orch.task_manager.register_handler("security", security_agent.handle_task)
    await security_agent.start()

    # Submit a task for the security agent
    task_id = await orch.submit_task(
        name="scan_api_deps",
        agent_type="security",
        action="scan_dependencies",
        params={"packages": ["flask==2.0.1", "requests==2.28.0"]},
    )
    print(f"Security scan task submitted: {task_id}")

    # Wait and check result
    import asyncio
    await asyncio.sleep(2)
    task = orch.task_manager.get_task(task_id)
    print(f"Scan result: {task.result if task else 'not found'}")

    await orch.stop()
