"""
Tool System  --  extensible plugin framework for agent capabilities.
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional, Callable
from abc import ABC, abstractmethod


@dataclass
class ToolResult:
    """Result from a tool execution."""
    success: bool
    data: Any = None
    error: Optional[str] = None
    execution_ms: float = 0.0
    tool_name: str = ""

    def __bool__(self):
        return self.success


class BaseTool(ABC):
    """Abstract base for all tools agents can use."""

    def __init__(self):
        self.name: str = self.__class__.__name__
        self.description: str = ""

    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given parameters."""
        ...

    def validate_params(self, **kwargs) -> Optional[str]:
        """Validate parameters. Return error message or None if valid."""
        return None

    async def safe_execute(self, **kwargs) -> ToolResult:
        """Execute with timing and error handling."""
        start = time.time()
        try:
            validation_error = self.validate_params(**kwargs)
            if validation_error:
                return ToolResult(success=False, error=validation_error, tool_name=self.name)

            result = await self.execute(**kwargs)
            elapsed = (time.time() - start) * 1000
            result.execution_ms = elapsed
            result.tool_name = self.name
            return result
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ToolResult(
                success=False,
                error=str(e),
                execution_ms=elapsed,
                tool_name=self.name,
            )


class ToolRegistry:
    """
    Registry of all available tools.
    Agents query this to find tools they can use.
    """

    def __init__(self):
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool, name: Optional[str] = None):
        key = name or tool.name
        self._tools[key] = tool

    def register_multiple(self, *tools: BaseTool):
        for t in tools:
            self.register(t)

    def get(self, name: str) -> Optional[BaseTool]:
        return self._tools.get(name)

    def list_tools(self, search: Optional[str] = None) -> list[dict[str, str]]:
        result = []
        for name, tool in self._tools.items():
            if search and search.lower() not in name.lower() and search.lower() not in tool.description.lower():
                continue
            result.append({"name": name, "description": tool.description})
        return result

    def unregister(self, name: str):
        self._tools.pop(name, None)

    @property
    def all(self) -> dict[str, BaseTool]:
        return dict(self._tools)
