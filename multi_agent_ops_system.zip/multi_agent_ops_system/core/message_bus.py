"""
Inter-agent Message Bus.
Provides async publish/subscribe communication between agents.
"""

import asyncio
import time
import uuid
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


class MessagePriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class Message:
    """A message exchanged between agents."""
    topic: str
    sender: str
    content: Any
    priority: MessagePriority = MessagePriority.NORMAL
    correlation_id: Optional[str] = None
    reply_to: Optional[str] = None
    message_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)

    def reply(self, content: Any, sender: str, **kwargs) -> "Message":
        """Create a reply message targeting the original sender."""
        return Message(
            topic=self.reply_to or f"reply:{self.topic}",
            sender=sender,
            content=content,
            correlation_id=self.message_id,
            reply_to=self.sender,
            **kwargs,
        )


class MessageBus:
    """
    Central message broker for agent communication.
    Supports pub/sub with topic filtering and priority queuing.
    """

    def __init__(self):
        self._subscribers: dict[str, list[Callable]] = {}
        self._agent_queues: dict[str, asyncio.Queue] = {}
        self._history: list[Message] = []
        self._max_history = 1000
        self._lock = asyncio.Lock()

    def subscribe(self, topic: str, callback: Callable):
        """Subscribe a callback to a topic. Supports wildcard '*'."""
        self._subscribers.setdefault(topic, []).append(callback)

    def unsubscribe(self, topic: str, callback: Callable):
        if topic in self._subscribers:
            self._subscribers[topic] = [c for c in self._subscribers[topic] if c != callback]

    def register_agent(self, agent_id: str):
        """Register an agent's direct message queue."""
        if agent_id not in self._agent_queues:
            self._agent_queues[agent_id] = asyncio.Queue()

    async def publish(self, message: Message):
        """Publish a message to all matching subscribers."""
        async with self._lock:
            self._history.append(message)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history:]

        # Direct agent delivery
        if message.reply_to and message.reply_to in self._agent_queues:
            await self._agent_queues[message.reply_to].put(message)

        # Topic-based fan-out
        tasks = []
        for topic_pattern, callbacks in self._subscribers.items():
            if self._topic_matches(topic_pattern, message.topic):
                for cb in callbacks:
                    tasks.append(self._safe_call(cb, message))

        if tasks:
            await asyncio.gather(*tasks)

    async def request(self, message: Message, timeout: float = 30.0) -> Optional[Message]:
        """Publish and wait for a reply (request-response pattern)."""
        reply_queue: asyncio.Queue = asyncio.Queue()
        temp_callback = lambda msg: asyncio.ensure_future(reply_queue.put(msg))

        self.subscribe(f"reply:{message.topic}", temp_callback)
        try:
            await self.publish(message)
            reply = await asyncio.wait_for(reply_queue.get(), timeout=timeout)
            return reply
        except asyncio.TimeoutError:
            return None
        finally:
            self.unsubscribe(f"reply:{message.topic}", temp_callback)

    async def consume(self, agent_id: str) -> Optional[Message]:
        """Consume the next message from an agent's direct queue."""
        if agent_id not in self._agent_queues:
            return None
        try:
            return await asyncio.wait_for(self._agent_queues[agent_id].get(), timeout=1.0)
        except asyncio.TimeoutError:
            return None

    def get_history(self, topic: Optional[str] = None, limit: int = 50) -> list[Message]:
        """Retrieve recent message history, optionally filtered by topic."""
        msgs = self._history
        if topic:
            msgs = [m for m in msgs if m.topic == topic]
        return msgs[-limit:]

    @staticmethod
    def _topic_matches(pattern: str, topic: str) -> bool:
        if pattern == "*":
            return True
        if pattern == topic:
            return True
        # wildcard segment: "agent.*" matches "agent.hello"
        p_parts = pattern.split(".")
        t_parts = topic.split(".")
        if len(p_parts) != len(t_parts):
            return False
        return all(p == t or p == "*" for p, t in zip(p_parts, t_parts))

    @staticmethod
    async def _safe_call(callback: Callable, message: Message):
        try:
            if asyncio.iscoroutinefunction(callback):
                await callback(message)
            else:
                callback(message)
        except Exception as e:
            print(f"[MessageBus] Error in subscriber callback: {e}")
