"""
Base Agent  --  abstract foundation for all specialized agents.
"""

import asyncio
import time
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Optional
from abc import ABC, abstractmethod

from core.message_bus import MessageBus, Message, MessagePriority
from core.task_manager import Task, TaskManager
from core.memory import SharedMemory, MemoryType
from core.tool_base import ToolRegistry
from core.monitoring import Logger, MetricsCollector, generate_trace_id


class AgentStatus(Enum):
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class AgentCapability:
    """Describes what an agent can do."""
    name: str
    description: str
    parameters: dict[str, type] = field(default_factory=dict)


class BaseAgent(ABC):
    """
    Abstract base agent.
    Every agent has a message bus connection, task handler,
    shared memory access, tool registry, and logging.
    """

    def __init__(
        self,
        agent_id: str,
        message_bus: MessageBus,
        task_manager: TaskManager,
        memory: SharedMemory,
        tool_registry: ToolRegistry,
        **kwargs,
    ):
        self.agent_id = agent_id
        self.bus = message_bus
        self.task_manager = task_manager
        self.memory = memory
        self.tools = tool_registry
        self.logger = Logger(f"Agent.{agent_id}")
        self.metrics = MetricsCollector()
        self.status = AgentStatus.IDLE

        # Message bus subscriptions
        self._subscriptions: list[str] = []

    @abstractmethod
    async def handle_task(self, task: Task) -> Any:
        """Handle a task dispatched to this agent type."""
        ...

    async def handle_message(self, message: Message):
        """Handle an incoming message. Override for custom behavior."""
        pass

    async def send_message(self, topic: str, content: Any,
                           priority: MessagePriority = MessagePriority.NORMAL,
                           **kwargs) -> Message:
        """Send a message via the bus."""
        msg = Message(
            topic=topic,
            sender=self.agent_id,
            content=content,
            priority=priority,
            **kwargs,
        )
        await self.bus.publish(msg)
        self.metrics.counter("messages_sent")
        return msg

    async def request(self, topic: str, content: Any,
                      timeout: float = 30.0, **kwargs) -> Optional[Message]:
        """Send a request and wait for a reply."""
        msg = Message(
            topic=topic,
            sender=self.agent_id,
            content=content,
            **kwargs,
        )
        self.metrics.counter("requests_sent")
        return await self.bus.request(msg, timeout=timeout)

    def remember(self, key: str, value: Any,
                 memory_type: MemoryType = MemoryType.SHORT_TERM,
                 tags: Optional[list[str]] = None,
                 ttl: Optional[float] = None) -> str:
        """Store a value in shared memory."""
        return self.memory.set(key, value, self.agent_id, memory_type, tags, ttl)

    def recall(self, key: str) -> Optional[Any]:
        """Retrieve a value from shared memory."""
        return self.memory.get(key)

    async def use_tool(self, tool_name: str, **params) -> Any:
        """Execute a registered tool."""
        tool = self.tools.get(tool_name)
        if not tool:
            raise ValueError(f"Tool '{tool_name}' not found in registry")
        result = await tool.safe_execute(**params)
        self.metrics.counter(f"tool_used:{tool_name}")
        return result

    def subscribe(self, topic: str):
        """Subscribe to a message topic."""
        self.bus.subscribe(topic, self.handle_message)
        self._subscriptions.append(topic)

    def log(self, level: str, message: str, **kwargs):
        getattr(self.logger, level.lower(), self.logger.info)(message, agent=self.agent_id, **kwargs)

    async def start(self):
        """Lifecycle hook  --  called when the agent is started."""
        self.status = AgentStatus.IDLE
        self.log("info", "Agent started")

    async def stop(self):
        """Lifecycle hook  --  called when the agent is stopped."""
        self.status = AgentStatus.STOPPED
        for topic in self._subscriptions:
            self.bus.unsubscribe(topic, self.handle_message)
        self.log("info", "Agent stopped")

    def status_report(self) -> dict:
        """Return agent status for monitoring."""
        return {
            "agent_id": self.agent_id,
            "type": self.__class__.__name__,
            "status": self.status.value,
            "metrics": {
                "messages_sent": self.metrics._counters.get("messages_sent", 0),
                "requests_sent": self.metrics._counters.get("requests_sent", 0),
            }
        }
