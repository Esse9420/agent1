"""
Task Manager  --  handles task creation, scheduling, dependency resolution,
and lifecycle management across agents.
"""

import asyncio
import time
import uuid
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Optional, Callable
from collections import defaultdict


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    LOW = 10
    NORMAL = 50
    HIGH = 100
    CRITICAL = 200


@dataclass
class Task:
    """A unit of work to be executed by an agent."""
    id: str
    name: str
    agent_type: str
    action: str
    params: dict[str, Any] = field(default_factory=dict)
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    depends_on: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Any = None
    error: Optional[str] = None
    assigned_to: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)
    timeout: Optional[float] = None  # seconds

    @property
    def duration_ms(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at) * 1000
        return None

    @classmethod
    def create(cls, name: str, agent_type: str, action: str,
               params: Optional[dict] = None, **kwargs) -> "Task":
        return cls(
            id=uuid.uuid4().hex[:12],
            name=name,
            agent_type=agent_type,
            action=action,
            params=params or {},
            **kwargs,
        )


class TaskManager:
    """
    Manages the full lifecycle of tasks: creation, scheduling,
    dependency resolution, dispatch, and result collection.
    """

    def __init__(self):
        self._tasks: dict[str, Task] = {}
        self._dependents: dict[str, set[str]] = defaultdict(set)  # task_id -> set of dependent task_ids
        self._handlers: dict[str, Callable] = {}  # agent_type -> handler
        self._lock = asyncio.Lock()
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None
        self._on_task_complete: list[Callable] = []

    def register_handler(self, agent_type: str, handler: Callable):
        """Register a handler function for a given agent type."""
        self._handlers[agent_type] = handler

    def add_task(self, task: Task) -> str:
        """Add a task to the manager."""
        self._tasks[task.id] = task
        for dep_id in task.depends_on:
            self._dependents[dep_id].add(task.id)
        return task.id

    def get_task(self, task_id: str) -> Optional[Task]:
        return self._tasks.get(task_id)

    def get_tasks_by_status(self, status: TaskStatus) -> list[Task]:
        return [t for t in self._tasks.values() if t.status == status]

    def get_ready_tasks(self) -> list[Task]:
        """Return tasks whose dependencies are all completed."""
        ready = []
        for task in self._tasks.values():
            if task.status != TaskStatus.PENDING:
                continue
            if all(
                self._tasks.get(dep_id) and self._tasks[dep_id].status == TaskStatus.COMPLETED
                for dep_id in task.depends_on
            ):
                ready.append(task)
        return sorted(ready, key=lambda t: (t.priority.value, t.created_at))

    async def start_worker(self):
        """Start the background worker that dispatches tasks."""
        self._running = True
        self._worker_task = asyncio.create_task(self._worker_loop())

    async def stop_worker(self):
        self._running = False
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass

    async def _worker_loop(self):
        """Continuously dispatch ready tasks."""
        while self._running:
            ready = self.get_ready_tasks()
            dispatched = False
            for task in ready:
                handler = self._handlers.get(task.agent_type)
                if handler:
                    dispatched = True
                    task.status = TaskStatus.RUNNING
                    task.started_at = time.time()
                    asyncio.create_task(self._execute_task(task, handler))
                else:
                    task.status = TaskStatus.FAILED
                    task.error = f"No handler for agent_type: {task.agent_type}"

            if not dispatched:
                await asyncio.sleep(0.2)

    async def _execute_task(self, task: Task, handler: Callable):
        """Execute a single task through its registered handler."""
        try:
            if task.timeout:
                result = await asyncio.wait_for(
                    handler(task), timeout=task.timeout
                )
            else:
                result = await handler(task)

            task.status = TaskStatus.COMPLETED
            task.result = result
        except asyncio.TimeoutError:
            task.status = TaskStatus.FAILED
            task.error = f"Task timed out after {task.timeout}s"
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
        finally:
            task.completed_at = time.time()
            for cb in self._on_task_complete:
                await self._safe_call(cb, task)

    def on_complete(self, callback: Callable):
        """Register a callback for task completion events."""
        self._on_task_complete.append(callback)

    def cancel_task(self, task_id: str) -> bool:
        task = self._tasks.get(task_id)
        if task and task.status in (TaskStatus.PENDING, TaskStatus.RUNNING):
            task.status = TaskStatus.CANCELLED
            return True
        return False

    def summary(self) -> dict:
        """Return a summary of task statuses."""
        counts = defaultdict(int)
        for t in self._tasks.values():
            counts[t.status.value] += 1
        return {
            "total": len(self._tasks),
            **counts,
        }

    @staticmethod
    async def _safe_call(callback, *args, **kwargs):
        try:
            if asyncio.iscoroutinefunction(callback):
                return await callback(*args, **kwargs)
            return callback(*args, **kwargs)
        except Exception as e:
            print(f"[TaskManager] Callback error: {e}")
