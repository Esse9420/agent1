"""
Monitoring & Observability module.
Provides structured logging, metrics collection, and tracing.
"""

import time
import uuid
import json
import os
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Optional
from datetime import datetime


class LogLevel(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


@dataclass
class LogEntry:
    timestamp: str
    level: LogLevel
    source: str
    message: str
    trace_id: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Logger:
    """Structured logger with trace context support."""

    def __init__(self, name: str, output_dir: Optional[str] = None):
        self.name = name
        self.output_dir = output_dir
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

    def _log(self, level: LogLevel, message: str, **kwargs):
        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            level=level,
            source=self.name,
            message=message,
            trace_id=kwargs.pop("trace_id", None),
            metadata=kwargs,
        )
        formatted = json.dumps(asdict(entry), ensure_ascii=False, default=str)
        print(formatted)

        if self.output_dir:
            log_file = os.path.join(
                self.output_dir, f"{datetime.now().strftime('%Y-%m-%d')}.log"
            )
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(formatted + "\n")

        return entry

    def debug(self, msg: str, **kw): return self._log(LogLevel.DEBUG, msg, **kw)
    def info(self, msg: str, **kw): return self._log(LogLevel.INFO, msg, **kw)
    def warning(self, msg: str, **kw): return self._log(LogLevel.WARNING, msg, **kw)
    def error(self, msg: str, **kw): return self._log(LogLevel.ERROR, msg, **kw)
    def critical(self, msg: str, **kw): return self._log(LogLevel.CRITICAL, msg, **kw)


@dataclass
class MetricPoint:
    name: str
    value: float
    labels: dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class MetricsCollector:
    """Simple metrics collector for agent observability."""

    def __init__(self):
        self._metrics: list[MetricPoint] = []
        self._counters: dict[str, int] = {}

    def counter(self, name: str, labels: Optional[dict[str, str]] = None) -> int:
        key = f"{name}:{json.dumps(labels or {}, sort_keys=True)}"
        self._counters.setdefault(key, 0)
        self._counters[key] += 1
        self._metrics.append(MetricPoint(name=f"counter:{name}", value=self._counters[key], labels=labels or {}))
        return self._counters[key]

    def gauge(self, name: str, value: float, labels: Optional[dict[str, str]] = None):
        self._metrics.append(MetricPoint(name=f"gauge:{name}", value=value, labels=labels or {}))

    def timing(self, name: str, duration_ms: float, labels: Optional[dict[str, str]] = None):
        self._metrics.append(MetricPoint(name=f"timing:{name}", value=duration_ms, labels=labels or {}))

    def snapshot(self) -> list[MetricPoint]:
        return self._metrics.copy()

    def clear(self):
        self._metrics.clear()
        self._counters.clear()


def generate_trace_id() -> str:
    return uuid.uuid4().hex[:16]
