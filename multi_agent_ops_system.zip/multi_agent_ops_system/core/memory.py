"""
Shared Memory  --  persistent context storage for agents.
Supports short-term (conversation) and long-term (episodic) memory.
"""

import time
import json
import uuid
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Any, Optional


class MemoryType(Enum):
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"
    WORKING = "working"


@dataclass
class MemoryEntry:
    """A single piece of information stored in shared memory."""
    id: str
    key: str
    value: Any
    agent_id: str
    memory_type: MemoryType = MemoryType.SHORT_TERM
    tags: list[str] = field(default_factory=list)
    ttl: Optional[float] = None  # seconds from created_at
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    @property
    def is_expired(self) -> bool:
        if self.ttl is None:
            return False
        return time.time() > self.created_at + self.ttl


class SharedMemory:
    """
    Shared memory store accessible by all agents.
    Supports key-value storage with tagging, TTL, and type-based isolation.
    """

    def __init__(self):
        self._store: dict[str, MemoryEntry] = {}
        self._tags_index: dict[str, set[str]] = {}

    def set(self, key: str, value: Any, agent_id: str,
            memory_type: MemoryType = MemoryType.SHORT_TERM,
            tags: Optional[list[str]] = None,
            ttl: Optional[float] = None) -> str:
        """Store a value in shared memory."""
        existing = self._find_by_key(key, memory_type)
        entry_id = existing.id if existing else uuid.uuid4().hex[:12]

        entry = MemoryEntry(
            id=entry_id,
            key=key,
            value=value,
            agent_id=agent_id,
            memory_type=memory_type,
            tags=tags or [],
            ttl=ttl,
            updated_at=time.time(),
        )
        if existing:
            entry.created_at = existing.created_at

        self._store[entry_id] = entry
        for tag in entry.tags:
            self._tags_index.setdefault(tag, set()).add(entry_id)

        return entry_id

    def get(self, key: str, memory_type: Optional[MemoryType] = None) -> Optional[Any]:
        """Retrieve a value by key."""
        entry = self._find_by_key(key, memory_type)
        if entry and not entry.is_expired:
            return entry.value
        if entry and entry.is_expired:
            self.delete(entry.id)
        return None

    def get_entry(self, key: str, memory_type: Optional[MemoryType] = None) -> Optional[MemoryEntry]:
        entry = self._find_by_key(key, memory_type)
        if entry and not entry.is_expired:
            return entry
        return None

    def delete(self, entry_id: str) -> bool:
        entry = self._store.pop(entry_id, None)
        if entry:
            for tag in entry.tags:
                if tag in self._tags_index:
                    self._tags_index[tag].discard(entry_id)
            return True
        return False

    def search_by_tag(self, tag: str) -> list[MemoryEntry]:
        """Find all entries with a given tag."""
        ids = self._tags_index.get(tag, set())
        return [
            self._store[eid] for eid in ids
            if eid in self._store and not self._store[eid].is_expired
        ]

    def search_by_value(self, predicate: callable) -> list[MemoryEntry]:
        """Find entries whose value satisfies a predicate."""
        return [
            entry for entry in self._store.values()
            if not entry.is_expired and predicate(entry.value)
        ]

    def cleanup_expired(self):
        """Remove all expired entries."""
        expired = [eid for eid, entry in self._store.items() if entry.is_expired]
        for eid in expired:
            self.delete(eid)

    def snapshot(self, memory_type: Optional[MemoryType] = None) -> dict:
        """Return a serializable snapshot for debugging."""
        result = {}
        for entry in self._store.values():
            if memory_type and entry.memory_type != memory_type:
                continue
            if not entry.is_expired:
                result[entry.key] = entry.value
        return result

    def _find_by_key(self, key: str, memory_type: Optional[MemoryType] = None) -> Optional[MemoryEntry]:
        for entry in self._store.values():
            if entry.key == key:
                if memory_type and entry.memory_type != memory_type:
                    continue
                return entry
        return None
