"""
Workflow Engine  --  defines and executes multi-step workflows
with conditional branching, retries, and parallel execution.
"""

import asyncio
import time
import uuid
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Optional, Callable


class WorkflowStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class WorkflowStep:
    """A single step within a workflow."""
    id: str
    name: str
    agent_type: str
    action: str
    params: dict[str, Any] = field(default_factory=dict)
    depends_on: list[str] = field(default_factory=list)
    retry_count: int = 0
    max_retries: int = 3
    timeout: Optional[float] = 300.0
    condition: Optional[Callable[[dict], bool]] = None  # context -> bool
    parallel_group: Optional[str] = None  # steps in same group run in parallel

    @classmethod
    def create(cls, name: str, agent_type: str, action: str,
               id: Optional[str] = None, **kwargs) -> "WorkflowStep":
        return cls(
            id=id or uuid.uuid4().hex[:8],
            name=name,
            agent_type=agent_type,
            action=action,
            **kwargs,
        )


@dataclass
class Workflow:
    """A complete workflow definition."""
    id: str
    name: str
    steps: list[WorkflowStep]
    status: WorkflowStatus = WorkflowStatus.PENDING
    context: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None

    @classmethod
    def create(cls, name: str, steps: list[WorkflowStep],
               context: Optional[dict] = None) -> "Workflow":
        return cls(id=uuid.uuid4().hex[:12], name=name, steps=steps,
                   context=context or {})


class WorkflowEngine:
    """
    Executes multi-step workflows with dependency resolution,
    conditional branching, retries, and parallel step execution.
    """

    def __init__(self, task_manager):
        self.task_manager = task_manager
        self._workflows: dict[str, Workflow] = {}
        self._step_results: dict[str, dict] = {}  # step_id -> result
        self._handlers: dict[str, Callable] = {}

    def register_step_handler(self, step_id: str, handler: Callable):
        """Register a direct handler for a workflow step."""
        self._handlers[step_id] = handler

    def add_workflow(self, workflow: Workflow) -> str:
        self._workflows[workflow.id] = workflow
        return workflow.id

    def get_workflow(self, workflow_id: str) -> Optional[Workflow]:
        return self._workflows.get(workflow_id)

    async def execute(self, workflow: Workflow) -> Workflow:
        """Execute a workflow, resolving dependencies and running steps."""
        workflow.status = WorkflowStatus.RUNNING
        completed = set()

        while len(completed) < len(workflow.steps):
            if workflow.status == WorkflowStatus.CANCELLED:
                break

            # Find steps ready to execute
            ready = self._get_ready_steps(workflow, completed)

            if not ready:
                if completed == {s.id for s in workflow.steps if not self._is_blocked(workflow, s)}:
                    break
                await asyncio.sleep(0.1)
                continue

            # Group by parallel_group
            groups: dict[str, list[WorkflowStep]] = {}
            for step in ready:
                g = step.parallel_group or step.id
                groups.setdefault(g, []).append(step)

            for group_steps in groups.values():
                tasks = [self._execute_step(workflow, step) for step in group_steps]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                for step, result in zip(group_steps, results):
                    if isinstance(result, Exception):
                        self._step_results[step.id] = {"error": str(result)}
                        step.retry_count += 1
                        if step.retry_count >= step.max_retries:
                            workflow.status = WorkflowStatus.FAILED
                            return workflow
                    else:
                        self._step_results[step.id] = result
                        completed.add(step.id)

        workflow.status = WorkflowStatus.COMPLETED
        workflow.completed_at = time.time()
        return workflow

    async def cancel(self, workflow_id: str):
        wf = self._workflows.get(workflow_id)
        if wf and wf.status == WorkflowStatus.RUNNING:
            wf.status = WorkflowStatus.CANCELLED

    def _get_ready_steps(self, workflow: Workflow, completed: set) -> list[WorkflowStep]:
        ready = []
        for step in workflow.steps:
            if step.id in completed:
                continue

            # Check dependencies
            deps_met = all(d in completed for d in step.depends_on)
            if not deps_met:
                continue

            # Check condition
            if step.condition and not step.condition(workflow.context):
                completed.add(step.id)
                continue

            # Check retry
            if step.retry_count >= step.max_retries:
                continue

            ready.append(step)
        return ready

    def _is_blocked(self, workflow: Workflow, step: WorkflowStep) -> bool:
        return any(
            d not in self._step_results and d != step.id
            for d in step.depends_on
        )

    async def _execute_step(self, workflow: Workflow, step: WorkflowStep) -> Any:
        """Execute a single workflow step."""
        handler = self._handlers.get(step.id)
        if handler:
            if asyncio.iscoroutinefunction(handler):
                return await handler(step, workflow.context)
            return handler(step, workflow.context)

        # Fall back to task manager
        from core.task_manager import Task
        task = Task.create(
            name=step.name,
            agent_type=step.agent_type,
            action=step.action,
            params={**step.params, "workflow_id": workflow.id, "step_id": step.id},
            timeout=step.timeout,
        )
        future = asyncio.get_event_loop().create_future()

        def on_complete(t: Task):
            if t.id == task.id and not future.done():
                if t.status.value == "completed":
                    future.set_result(t.result)
                else:
                    future.set_exception(RuntimeError(t.error or "Step failed"))

        self.task_manager.add_task(task)
        self.task_manager.on_complete(on_complete)

        try:
            return await asyncio.wait_for(future, timeout=step.timeout + 10)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Step '{step.name}' timed out after {step.timeout}s")

    def get_result(self, workflow_id: str, step_id: str) -> Optional[Any]:
        return self._step_results.get(step_id)
