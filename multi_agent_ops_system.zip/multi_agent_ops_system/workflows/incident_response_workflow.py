"""Incident Response Workflow -- automated incident triage and resolution."""
from core.workflow_engine import Workflow, WorkflowStep


def create_incident_response_workflow(
    incident_id: str,
    severity: str,
    description: str,
    affected_service: str,
) -> Workflow:
    """Create an incident response workflow."""
    is_critical = severity in ("high", "critical")

    steps = [
        WorkflowStep.create(
            name=f"triage_{incident_id}",
            agent_type="analyzer",
            action="root_cause",
            id="triage",
            params={"error": description, "context": {"service": affected_service, "severity": severity}},
        ),
        WorkflowStep.create(
            name=f"health_check_{incident_id}",
            agent_type="monitor",
            action="health_check",
            id="health_check",
            params={"checks": ["agent_status", "tools"]},
            depends_on=["triage"],
        ),
        WorkflowStep.create(
            name=f"log_analysis_{incident_id}",
            agent_type="analyzer",
            action="analyze_logs",
            id="log_analysis",
            params={"source": affected_service, "filter": "ERROR|CRITICAL", "time_range": 1800},
            depends_on=["triage"],
        ),
        WorkflowStep.create(
            name=f"contain_{incident_id}",
            agent_type="executor",
            action="shell",
            id="contain",
            params={"command": f"echo 'Containment: isolating {affected_service}'", "timeout": 30},
            depends_on=["health_check", "log_analysis"],
            condition=lambda ctx: ctx.get("severity") in ("high", "critical"),
        ),
        WorkflowStep.create(
            name=f"remediate_{incident_id}",
            agent_type="executor",
            action="shell",
            id="remediate",
            params={"command": f"echo 'Remediation: applying fix to {affected_service}'", "timeout": 60},
            depends_on=["contain"] if is_critical else ["health_check", "log_analysis"],
        ),
        WorkflowStep.create(
            name=f"verify_{incident_id}",
            agent_type="monitor",
            action="verify_result",
            id="verify",
            params={"expected": {"healthy": True}},
            depends_on=["remediate"],
        ),
        WorkflowStep.create(
            name=f"postmortem_{incident_id}",
            agent_type="analyzer",
            action="generate_report",
            id="postmortem",
            params={
                "type": "incident_report",
                "data": {
                    "incident_id": incident_id,
                    "severity": severity,
                    "service": affected_service,
                    "description": description,
                },
            },
            depends_on=["verify"],
        ),
    ]

    return Workflow.create(
        name=f"incident_{incident_id}",
        steps=steps,
        context={"incident_id": incident_id, "severity": severity, "service": affected_service},
    )
