"""Deployment workflow -- multi-step deploy with verification."""
from core.workflow_engine import Workflow, WorkflowStep


def create_deployment_workflow(service_name: str, version: str, target: str) -> Workflow:
    """Create a deployment workflow for a service."""
    steps = [
        WorkflowStep.create(
            name=f"analyze_{service_name}",
            agent_type="analyzer",
            action="analyze_logs",
            id="analyze",
            params={"source": service_name, "filter": "error", "time_range": 3600},
        ),
        WorkflowStep.create(
            name=f"prepare_{target}",
            agent_type="executor",
            action="shell",
            id="prepare",
            params={"command": f"echo 'Preparing {target} for {service_name}:{version}'", "timeout": 30},
        ),
        WorkflowStep.create(
            name=f"backup_{service_name}",
            agent_type="executor",
            action="file_operation",
            id="backup",
            params={"operation": "write", "path": f"/tmp/backup_{service_name}.flag"},
        ),
        WorkflowStep.create(
            name=f"deploy_{service_name}",
            agent_type="executor",
            action="deploy",
            id="deploy",
            params={
                "target": target,
                "steps": [
                    f"echo 'Deploying {service_name} version {version} to {target}'",
                    f"echo 'Stopping service {service_name}'",
                    f"echo 'Copying artifacts'",
                    f"echo 'Starting service {service_name}'",
                ],
                "timeout": 120,
            },
            depends_on=["prepare", "backup"],
        ),
        WorkflowStep.create(
            name=f"verify_{service_name}",
            agent_type="monitor",
            action="health_check",
            id="verify",
            params={"checks": ["agent_status"]},
            depends_on=["deploy"],
        ),
        WorkflowStep.create(
            name=f"report_{service_name}",
            agent_type="analyzer",
            action="generate_report",
            id="report",
            params={
                "type": "deployment",
                "data": {"service": service_name, "version": version, "target": target},
            },
            depends_on=["verify"],
        ),
    ]

    return Workflow.create(
        name=f"deploy_{service_name}_{version}",
        steps=steps,
        context={"service": service_name, "version": version, "target": target},
    )
